FALAK KIRANA STORE WEBSITE

Files included:
1. index.html  -> Main website file

How to use:
- Mobile/PC me index.html open karo
- GitHub Pages par upload karke FREE live karo

WhatsApp Number: 7317469524
